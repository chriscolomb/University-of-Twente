class Reservation {
	constructor(id, roomId, startTime, endTime, meetingName, reserverId, reserverName, headcount, privateMeeting = false) {
		this.id = id;
		this.roomId = roomId;
		this.startTime = startTime;
		this.endTime = endTime;
		this.meetingName = meetingName;
		this.reserverId = reserverId;
		this.reserverName = reserverName;
		this.headcount = headcount;
		this.privateMeeting = privateMeeting;
	}
	
	getState(date = new Date()) {
		if (date.getTime() < this.startTime) {
			if (this.startTime - date.getTime() > 300000) {
				return 0;
			} else {
				return 1;
			}
		} else if (date.getTime() < this.endTime) {
			if (this.endTime - date.getTime() > 300000) {
				return 2;
			} else {
				return 3;
			}
		} else {
			return 4;
		}
	}
	
	toHTML(state = this.getState()) {
		var html = "\n<h1>Room " + this.roomId + "</h1>\n" +
				"<hr>\n";
		switch (state) {
			case 1:
				html += "<h2>Occupied Soon</h2>\n";
				break;
			case 2:
				html += "<h2>Occupied</h2>\n";
				break;
			case 3:
				html += "<h2>Available Soon</h2>\n";
				break;
			default:
				html += "<h2>Available</h2>\n";
				break;
		}
		if (state > 0 && state < 4) {
			html += "<h3>" + Clock.getLocaleTimeString(this.startTime) + " - " + Clock.getLocaleTimeString(this.endTime) + "</h3>\n" +
					"<hr>\n" +
					"<h4>" + this.meetingName + "</h4>\n";
			if (!this.privateMeeting) {
				html += "<h5>" + this.reserverName + " and " + (this.headcount - 1) + " others</h5>\n";
			}
		}
		return html;
	}
}

$(function() {
	var previousReservations = [];
	var update = function (reservation, removed = false) {
		var room = $("#" + reservation.roomId);
		if (!removed) {
			switch (reservation.getState()) {
				case 0:
				case 4:
					room.attr("class", "col-12 btn btn-success btn-lg");
					break;
				case 1:
				case 3:
					room.attr("class", "col-12 btn btn-warning btn-lg");
					break;
				default:
					room.attr("class", "col-12 btn btn-danger btn-lg");
					break;
			}
			room.html(reservation.toHTML());
		} else {
			room.attr("class", "col-12 btn btn-success btn-lg");
			room.html(reservation.toHTML(0));
		}
	}
	var loop = function () {
		var request = new XMLHttpRequest();
		request.open("GET", "./rest/reservations/overview");
		request.setRequestHeader("Content-Type", "application/json");
		request.onreadystatechange = function () {
			if (request.readyState === 4) {
				if (request.status === 200) {
					var json = JSON.parse(request.responseText);
					var reservations = [];
					json.forEach(function (object) {
						reservations.push(new Reservation(object.id, object.roomId, object.startTime, object.endTime,
								object.meetingName, object.reserverId, object.reserverName, object.headcount,
								object.privateMeeting));
					});
					previousReservations.filter(function (reservation) {
						return !reservations.includes(reservation);
					}).forEach(function (reservation) {
						update(reservation, true);
					});
					reservations.forEach(function (reservation) {
						update(reservation);
					});
					previousReservations = reservations;
					setTimeout(loop, 1000);
				} else {
					console.log("Error: Retrieving reservations failed");
				}
			}
		}
		request.send();
	}
	loop();
});