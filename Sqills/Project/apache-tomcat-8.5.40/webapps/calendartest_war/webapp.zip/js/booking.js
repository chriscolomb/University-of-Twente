function submit() {
    var reservation = "{\"id\":0,\"roomId\":";
    reservation += $('#room').prop('value');
    reservation += ",\"startTime\":";
    var date = new Date().toString();
    reservation += new Date(date.substring(0, 16) + $('#startTime').prop('value') + ":00" + date.substring(24)).getTime();
    reservation += ",\"endTime\":";
    reservation += new Date(date.substring(0, 16) + $('#endTime').prop('value') + ":00" + date.substring(24)).getTime();
    var privateMeeting = $('#privateMeeting').prop('checked');
    reservation += ",\"meetingName\":\"";
    reservation += privateMeeting ? "Private Meeting" : $('#meetingName').prop('value');
    reservation += "\",\"reserverId\":";
    reservation += $('#employeeNumber').prop('value');
    reservation += ",\"reserverName\":\"";
    reservation += privateMeeting ? "Private" : $('#firstName').prop('value') + " " + $('#lastName').prop('value');
    reservation += "\",\"headcount\":"
    reservation += privateMeeting ? 0 : $('#headcount').prop('value');
    reservation += ",\"privateMeeting\":";
    reservation += privateMeeting;
    reservation += "}";
    var request = new XMLHttpRequest();
    request.open("POST", "./rest/reservations");
    request.setRequestHeader("Content-Type", "application/json");
    request.onreadystatechange = function () {
    	if (request.readyState === 4) {
    		var response = JSON.parse(request.responseText);
    		if (request.status === 200) {
    			$("#successModalBody").html("Reservation was successfully made. Your reservation id is " + response.id + ".");
    			$("#successModalButton").click(function () {
    				$("form").trigger("reset");
    			});
    			$("#successModal").modal("show");
    		} else if (request.status === 400) {
    			console.log(response);
    		} else if (request.status === 500) {
    			console.log(response);
    		}
    	}
    }
    request.send(reservation);
}

function convert(time) {
    if (typeof time === 'string') {
        if (/^(0[0-9]|1[0-9]|2[0-3]):(0[0-9]|[1-5][0-9])$/.test(time)) {
            return parseInt(time.substring(0, 2)) * 60 + parseInt(time.substring(3, 5));
        } else {
            console.log(time + " is in wrong format. Correct format is hh:mm.");
        }
    } else if (typeof time === 'number') {
        if (time >= 0 && time < 1440) {
            var hours = Math.floor(time / 60);
            var minutes = time % 60;
            return (hours < 10 ? "0" + hours : hours) + ":" + (minutes < 10 ? "0" + minutes : minutes);
        } else if (time < 0) {
            return "00:00";
        } else {
            return "23:59";
        }
    }
}

$(document).ready(function () {
    $('#privateMeeting').change(function () {
        var notRequired = $('#not-required');
        if (this.checked) {
            notRequired.hide();
            notRequired.children().children('input').prop('required', false);
        } else {
            notRequired.show();
            notRequired.children().children('input').prop('required', true);
        }
    });
    var startTime = $('#startTime');
    var endTime = $('#endTime');
    startTime.change(function () {
        endTime.attr('min', convert(convert(this.value) + 1));
    })
    endTime.change(function () {
        startTime.attr('max', convert(convert(this.value) - 1));
    })
    var time = new Date().toTimeString().substring(0, 5);
    startTime.attr('value', time);
    endTime.attr('min', convert(convert(startTime.prop('value')) + 1));
    endTime.attr('value', convert(convert(time) + 30));
    startTime.attr('max', convert(convert(endTime.prop('value')) - 1));
});