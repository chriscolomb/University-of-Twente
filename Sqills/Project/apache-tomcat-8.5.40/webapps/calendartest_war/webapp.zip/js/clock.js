class Clock {
	static getLocaleTimeString(date = new Date()) {
		if (typeof date === 'number') {
			date = new Date(date);
		}
		var localeTimeString = date.toLocaleTimeString();
		return localeTimeString.substring(0,5) + localeTimeString.substring(8, 11);
	}
	
	constructor(id, text = "") {
		this.id = id;
		this.text = text;
		this.timeoutId = -1;
	}
	
	start() {
		var loop = function (clock) {
			$("#" + clock.id).html(clock.text + new Date().toString().substring(0, 24));
			clock.timeoutId = setTimeout(loop, 1000, clock);
		}
		loop(this);
	}
	
	stop() {
		clearTimeout(this.timeoutId);
	}
}

$(function () {
	new Clock("clock").start();
});